package io.pivotal.baidupushdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText inputField;
    private View submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputField = (EditText) findViewById(R.id.main_input_text);
        submitButton = findViewById(R.id.main_submit_button);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BaiduPushSender.sendPushRequest(inputField.getText().toString());
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
    }


}
