package io.pivotal.baidupushdemo;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

public class BaiduPushSender {

//    private static final String BAIDU_PUSH_URL = "http://api.tuisong.baidu.com/rest/3.0/push/all";
    private static final String BAIDU_PUSH_URL = "http://api.tuisong.baidu.com/rest/3.0/push/batch_device";

    private static final String POST = "POST";
    private static final String CONTENT_TYPE = "Content-Type";
    private static final String USER_AGENT = "User-Agent";

    private static final String APPLICATION_URLENCODED = "application/x-www-form-urlencoded;charset=utf-8";

    private static final String BAIDU_SECRET_KEY = "9FMnvO3dm8uE6ACa0lsUGI1vp4RWhnjy";
    private static final String BAIDU_API_KEY = "UUZr1NXHfpT13eGn2MLWOcBD";


    public static void sendPushRequest(final String message) {

        AsyncTask<Void, Void, Void> asyncTask = new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... p) {

                OutputStream outputStream = null;

                try {
                    final URL url = new URL(BAIDU_PUSH_URL);
                    final HttpURLConnection urlConnection = getUrlConnection(url);

                    String messageJson = "{ \"title\" : \"hello\" , \"description\": \"" + message + "\"}";
                    String currentTimeInSeconds = getCurrentTimeInSeconds();

                    StringBuilder sb = new StringBuilder();
                    Map<String, String> params = new TreeMap<>();
                    params.put("msg", messageJson);
                    params.put("msg_type", "1");
                    params.put("apikey", BAIDU_API_KEY);
                    params.put("timestamp", currentTimeInSeconds);
                    params.put("channel_ids", "[" + "4602666445963748739" + "]");

                    for (Map.Entry<String, String> entry : params.entrySet()) {
                        Log.e("XTREME", "entry: " + entry);
                        sb.append(entry.getKey()).append('=').append(entry.getValue());
                        sb.append("&");
                    }

                    sb.append("sign=");
                    sb.append(new PushSignatureDigest().digest(POST, BAIDU_PUSH_URL, BAIDU_SECRET_KEY, params));

                    outputStream = new BufferedOutputStream(urlConnection.getOutputStream());
                    writeConnectionOutput(sb.toString(), outputStream);

                    final int statusCode = urlConnection.getResponseCode();
                    Log.e("XTREME", "sendPushRequest return with status: " + statusCode);
                    Log.e("XTREME", "sendPushRequest return with message: " + urlConnection.getResponseMessage());
                    urlConnection.disconnect();

                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
                return null;
            }
        };

        asyncTask.execute((Void) null);
    }

    private static void writeConnectionOutput(String requestBodyData, OutputStream outputStream) throws IOException {
        final byte[] bytes = requestBodyData.getBytes();
        for (byte b : bytes) {
            outputStream.write(b);
        }
        outputStream.close();
    }

    private static String getCurrentTimeInSeconds() {
        return Long.toString(TimeUnit.MILLISECONDS.toSeconds(System.currentTimeMillis()));
    }

    private static HttpURLConnection getUrlConnection(URL url) throws IOException {
        final HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        urlConnection.setDoInput(true);
        urlConnection.setRequestMethod(POST);
        urlConnection.setConnectTimeout(60000);
        urlConnection.setReadTimeout(60000);
        urlConnection.addRequestProperty(CONTENT_TYPE, APPLICATION_URLENCODED);
        urlConnection.addRequestProperty(USER_AGENT, "BCCS_SDK/3.0");

        urlConnection.setDoOutput(true);
        urlConnection.connect();

        return urlConnection;
    }

    private static String getMessageJson(String message) {
//        return "{ \"title\" : \"hello\" , \"description\": \"" + message + "\" }";
        return message;
    }
}
