package io.pivotal.baidupushdemo;

import android.app.Application;

import com.baidu.android.pushservice.BasicPushNotificationBuilder;
import com.baidu.android.pushservice.PushConstants;
import com.baidu.android.pushservice.PushManager;
import com.baidu.android.pushservice.PushNotificationBuilder;


public class BaiduPushDemoApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        PushManager.startWork(this, PushConstants.LOGIN_TYPE_API_KEY, "UUZr1NXHfpT13eGn2MLWOcBD");

        PushNotificationBuilder builder = new BasicPushNotificationBuilder();
        builder.setNotificationTitle("Overridden Title");
        builder.setStatusbarIcon(android.R.drawable.ic_lock_idle_charging);

        PushManager.setDefaultNotificationBuilder(this, builder);
    }
}
